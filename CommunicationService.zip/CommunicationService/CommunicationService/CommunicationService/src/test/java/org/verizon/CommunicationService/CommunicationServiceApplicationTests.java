package org.verizon.CommunicationService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CommunicationServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
